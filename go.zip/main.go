package main

import (
    "html/template"
    "net/http"
)

type User struct {
    Name  string
    Age   int
    Email string
}

func handler(w http.ResponseWriter, r *http.Request) {
    // Parse the template file
    tmpl, err := template.ParseFiles("./template.html")
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    // Data to pass to the template
    user := User{
        Name:  "Rocy ",
        Age:   30,
        Email: "Rocky@example.com",
    }

    // Execute the template and pass the data
    err = tmpl.Execute(w, user)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
    }
}

func main() {
    http.HandleFunc("/", handler)
    http.ListenAndServe(":8080", nil)
}
