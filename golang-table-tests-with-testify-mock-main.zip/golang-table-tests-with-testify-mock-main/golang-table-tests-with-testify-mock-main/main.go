package main

import (
	"mockTest/computer"
	"mockTest/cpu"
	"mockTest/gpu"
	"mockTest/memory"
)

func main() {
	intel := &cpu.Intel{}
	nvidia := &gpu.Nvidia{}
	samsung := &memory.Samsung{}
	_ = computer.NewMacBook(intel, nvidia, samsung)
}
