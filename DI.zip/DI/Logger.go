package main

import "fmt"

// Logger is the interface that wraps basic logging methods.
type Logger interface {
    Log(message string)
}

// ConsoleLogger is a concrete implementation of Logger that logs to the console.
type ConsoleLogger struct{}

func (cl ConsoleLogger) Log(message string) {
    fmt.Println(message)
}
