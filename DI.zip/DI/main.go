package main

func main() {
    // Initialize the service using the generated Wire code.
    service := InitializeService()

    // Use the service.
    service.PerformAction()
}
