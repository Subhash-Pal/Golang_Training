package main

// Service depends on a Logger to log messages.
type Service struct {
    logger Logger
}

func NewService(logger Logger) *Service {
    return &Service{logger: logger}
}

func (s *Service) PerformAction() {
    s.logger.Log("Performing an action")
}
