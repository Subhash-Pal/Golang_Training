// The `//+build wireinject` comment is a build constraint in Go that indicates to the `wire` tool that
// this file should be included when running wire code generation. The `wire` tool is a dependency
// injection framework for Go that generates code based on the dependency injection configuration
// defined in the source code. By including the `//+build wireinject` comment, the `wire` tool knows to
// process this file during code generation to wire up dependencies.
//+build wireinject

package main

import "github.com/google/wire"
// The `//+build wireinject` comment is a build constraint in Go that indicates to the `wire` tool that
// this file should be included when running wire code generation. This comment tells the `wire` tool
// to process this file during code generation to wire up dependencies based on the dependency
// injection configuration defined in the source code.

// ProvideConsoleLogger creates a new ConsoleLogger.
func ProvideConsoleLogger() Logger {
    return &ConsoleLogger{}
}

// ProvideService creates a new Service.
func ProvideService(logger Logger) *Service {
    return NewService(logger)
}

// InitializeService initializes a Service using Wire.
func InitializeService() *Service {
    wire.Build(ProvideConsoleLogger, ProvideService)
    return nil
}
